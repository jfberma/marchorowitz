from fabric.api import task


@task
def update_apt():
    pass
