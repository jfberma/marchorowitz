class ConfigurationError(Exception): pass
class InstrumentationError(Exception): pass
