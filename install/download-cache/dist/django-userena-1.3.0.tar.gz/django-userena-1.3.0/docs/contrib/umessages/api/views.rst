.. _messages-api-views:

Views
=====

.. automodule:: userena.contrib.umessages.views

MessageListView
---------------

.. autofunction:: userena.contrib.umessages.views.MessageListView

MessageDetailListView
---------------------

.. autofunction:: userena.contrib.umessages.views.MessageDetailListView

message_compose
---------------

.. autofunction:: userena.contrib.umessages.views.message_compose

message_remove
--------------

.. autofunction:: userena.contrib.umessages.views.message_remove
