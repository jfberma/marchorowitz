from userena.contrib.umessages.tests.test_fields import *
from userena.contrib.umessages.tests.test_forms import *
from userena.contrib.umessages.tests.test_managers import *
from userena.contrib.umessages.tests.test_models import *
from userena.contrib.umessages.tests.test_views import *
