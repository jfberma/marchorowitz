import os
from test_settings_bootstrap import *


CRISPY_TEMPLATE_PACK = 'uni_form'
