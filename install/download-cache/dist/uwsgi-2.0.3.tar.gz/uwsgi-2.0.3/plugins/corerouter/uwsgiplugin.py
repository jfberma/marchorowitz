
NAME='corerouter'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['cr_common', 'cr_map', 'corerouter']
