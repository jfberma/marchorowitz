NAME='cplusplus'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lstdc++']
GCC_LIST = ['base.cc', 'plugin']
