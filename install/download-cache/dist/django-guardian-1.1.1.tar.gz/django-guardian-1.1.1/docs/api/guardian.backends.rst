.. _api-backends:

Backends
========

.. automodule:: guardian.backends


ObjectPermissionBackend
-----------------------

.. autoclass:: guardian.backends.ObjectPermissionBackend
   :members:

