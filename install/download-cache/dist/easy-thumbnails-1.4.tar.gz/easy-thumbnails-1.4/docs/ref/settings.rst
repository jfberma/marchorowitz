========
Settings
========

.. autoclass:: easy_thumbnails.conf.Settings()
   :members: