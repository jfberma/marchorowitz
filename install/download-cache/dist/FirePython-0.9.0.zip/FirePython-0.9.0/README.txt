FirePython
==========

FirePython is a sexy Python logger console integrated into Firebug.
Visit `firepython.binaryage.com`_.

.. _firepython.binaryage.com: http://firepython.binaryage.com
.. vim:filetype=rst
