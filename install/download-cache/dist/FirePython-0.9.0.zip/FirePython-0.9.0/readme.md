# FirePython

FirePython is a sexy Python logger console integrated into Firebug.

<a href="http://firepython.binaryage.com"><img src="http://firepython.binaryage.com/shared/img/firepython-mainshot.png"></a>

## Visit [firepython.binaryage.com](http://firepython.binaryage.com)
