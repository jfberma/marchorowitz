.. _extensions_storemagic:

==========
storemagic
==========

.. automodule:: IPython.extensions.storemagic
   :members: store
