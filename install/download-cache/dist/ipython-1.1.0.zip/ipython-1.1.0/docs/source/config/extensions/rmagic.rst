.. _extensions_rmagic:

===========
rmagic
===========

.. automodule:: IPython.extensions.rmagic
