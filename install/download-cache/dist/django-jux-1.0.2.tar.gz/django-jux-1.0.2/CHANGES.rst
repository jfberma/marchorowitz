Changelog for django-jux
========================

1.0.2 (2011-09-15)
------------------

- Added classifiers to setup.py (Thanks, pypi-classifiers!)


1.0.1 (2011-09-10)
------------------

- Updated package metadata to make the license field a little more descriptive
- Renamed ReST docs to have .rst extension, pulled .txt off of LICENSE
- Trying out zest.releaser (Seems like just the ticket so far...)


1.0 (2011-09-10)
------------------

- Initial Release
