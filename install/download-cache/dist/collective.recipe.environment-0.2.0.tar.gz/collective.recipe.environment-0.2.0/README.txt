# See collective/recipe/environment/README.txt
